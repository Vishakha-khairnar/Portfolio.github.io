// Show welcome message
function showMessage() {
  alert("Welcome to my MCA Portfolio Website!");
}

// Smooth scrolling for navbar links
document.addEventListener("DOMContentLoaded", () => {
  const navLinks = document.querySelectorAll("nav a");
  const sections = document.querySelectorAll(".section");

  // Default section
  document.getElementById("home").classList.add("active");

  navLinks.forEach(link => {
    link.addEventListener("click", function (e) {
      e.preventDefault();

      const targetId = this.getAttribute("href").replace("#", "");

      // Hide all sections
      sections.forEach(section => {
        section.classList.remove("active");
      });

      // Show clicked section
      const targetSection = document.getElementById(targetId);
      if (targetSection) {
        targetSection.classList.add("active");
      }
    });
  });
});
// Simple console message
console.log("Portfolio website loaded successfully");
// Contact form submission
function submitForm(event) {
  event.preventDefault();

  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const message = document.getElementById("message").value;

  if (name && email && message) {
    alert("Thank you, " + name + "! Your message has been sent.");
    
    // Clear form
    document.getElementById("name").value = "";
    document.getElementById("email").value = "";
    document.getElementById("message").value = "";
  } else {
    alert("Please fill in all fields.");
  }
}
// Set current year in footer
document.getElementById("year").textContent = new Date().getFullYear();

